#include "answer02.h"
 
size_t my_strlen(const char * str)
{
	size_t len = 0;

	while(*str != '\0')
	{
		len++;
		str++;
	}

	return len;
}

int my_countchar(const char * str, char ch)
{
	int num = 0;
	
	while(*str != '\0')
	{
		if(*str == ch)
		{
			num++;
		}
		str++;
	}

	return num;
}

char * my_strchr(const char * str, int ch)
{
	char *p = NULL;

	do 
	{
		if(*str == ch)
		{
			p = (char *) str;
		}
	
	}
	while(*str++ != '\0' && p == NULL);

	return p;
}

char * my_strrchr(const char * str, int ch)
{

	char *p = NULL;
	size_t chLen = my_strlen(str);
	char *a = (char *) str;
	a += chLen;
	
	do 
	{
		if(*a == ch)
		{
			p = a;
		}
		if(chLen > 0)
		{
		a--;
		}
	
	}
	while(chLen-- > 0  && p == NULL);

	return p;
}

char * my_strstr(const char * haystack, const char * needle)
{
	char *t = NULL;
	if(*needle == '\0')
	{
		return (char *) haystack;
	}

	else
	{

	while(*haystack != '\0')
	{
		if(*haystack == *needle)
		{
			t = (char *) haystack;
			int flag = 1;
			size_t len = my_strlen(needle);
			while(len > 1 && flag ==1)
			{
				haystack++;
				needle++;
				if(*haystack != *needle)
				{
					flag = 0;
				}

				len--;
			}

			if(flag == 1)
			{
				return t;
			
			}
			else
			{
				t = NULL;
			}
		}
		haystack++;
	}
	}
	return t;
}

char * my_strcpy(char * dest, const char * src)
{
	size_t sLen;
	sLen = my_strlen(src);
	int c;
	for(c = 0; c < sLen; c++)
	{
		*dest = *src;
		dest++;
		src++;

	}

	*dest= '\0';
	dest -= sLen;

	return dest;
}

char * my_strcat(char * dest, const char * src)
{
	size_t sLen, dLen;
	sLen = my_strlen(src);
	dLen = my_strlen(dest);
	dest += dLen;
	int c;
	
	for(c = 0; c < sLen; c++)
	{
		*dest = *src;
		dest++;
		src++;
	}

	*dest = '\0';
	dest -= (sLen + dLen);
	return dest;
}

int my_isspace(int ch)
{
	int isSpace = 0;

	if(ch == ' ' || ch == '\f' || ch == '\n' || ch == '\r' || ch == '\t' || ch == '\v')
	{
		isSpace = 1;
	}

	return isSpace;

}

int my_atoi(const char * str)
{
	int ret = 0;
	int nflag = 1;
	while(*str != '\0')
	{
		if(my_isspace(*str))
		{
			str++;
		}
		else if(*str == '-')
		{
			nflag = -1;
			str++;
		}
		else if((*str >= '0') && (*str <='9'))
		{
			while( (*str >= '0') && (*str <= '9') && *str != '\0')
			{
				ret *= 10;
				ret += *str - '0';
				str++;
			}

			return (nflag * ret);

		}
		else
		{
			str++;
		}


	}
	return nflag*ret;
}

